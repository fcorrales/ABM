﻿using System.Linq;
using System.Web.Services;
using System.Xml;
using System.Xml.Linq;

namespace Exercise3
{
    /// <summary>
    /// Web service to analyze the structe of the xml
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    public class WebService : System.Web.Services.WebService
    {
        [WebMethod]
        public int AnalyzeXmlStructure(XmlDocument xmlDocument)
        {
            XDocument xDocument = XDocument.Parse(xmlDocument.OuterXml);

            string declarationCommand = xDocument.Descendants("Declaration").Attributes("Command").Single().Value;
            if (declarationCommand != "DEFAULT")
            {
                return -1;
            }

            string siteId = xDocument.Descendants("SiteID").Single().Value;
            if (siteId != "DUB")
            {
                return -2;
            }

            return 0;
        }
    }
}

﻿using System;
using System.Xml;

namespace WebServiceTest
{
    class Program
    {
        static void Main()
        {
            AnalyzeStructureStructuredCorrectly();
            AnalyzeStructureWrongCommandDeclaration();
            AnalyzeStructureWrongSiteId();
        }

        private static void AnalyzeStructureStructuredCorrectly()
        {
            XmlDocument xmlDocument = new XmlDocument();

            xmlDocument.LoadXml(@"
                <InputDocument>
	                <DeclarationList>
		                <Declaration Command=""DEFAULT"" Version=""5.13"">
			                <DeclarationHeader>
				                <Jurisdiction>IE</Jurisdiction>
				                <CWProcedure>IMPORT</CWProcedure>
							                <DeclarationDestination>CUSTOMSWAREIE</DeclarationDestination>
				                <DocumentRef>71Q0019681</DocumentRef>
				                <SiteID>DUB</SiteID>
				                <AccountCode>G0779837</AccountCode>
			                </DeclarationHeader>
		                </Declaration>
	                </DeclarationList>
                </InputDocument>
            ");

            WebService.WebService webService = new WebService.WebService();

            int statusCode = webService.AnalyzeXmlStructure(xmlDocument);

            if (statusCode != 0)
            {
                throw new Exception("Wrong status code");
            }
        }

        private static void AnalyzeStructureWrongCommandDeclaration()
        {
            XmlDocument xmlDocument = new XmlDocument();

            xmlDocument.LoadXml(@"
                <InputDocument>
	                <DeclarationList>
		                <Declaration Command=""CUSTOM"" Version=""5.13"">
			                <DeclarationHeader>
				                <Jurisdiction>IE</Jurisdiction>
				                <CWProcedure>IMPORT</CWProcedure>
							                <DeclarationDestination>CUSTOMSWAREIE</DeclarationDestination>
				                <DocumentRef>71Q0019681</DocumentRef>
				                <SiteID>DUB</SiteID>
				                <AccountCode>G0779837</AccountCode>
			                </DeclarationHeader>
		                </Declaration>
	                </DeclarationList>
                </InputDocument>
            ");

            WebService.WebService webService = new WebService.WebService();

            int statusCode = webService.AnalyzeXmlStructure(xmlDocument);

            if (statusCode != -1)
            {
                throw new Exception("Wrong status code");
            }
        }

        private static void AnalyzeStructureWrongSiteId()
        {
            XmlDocument xmlDocument = new XmlDocument();

            xmlDocument.LoadXml(@"
                <InputDocument>
	                <DeclarationList>
		                <Declaration Command=""DEFAULT"" Version=""5.13"">
			                <DeclarationHeader>
				                <Jurisdiction>IE</Jurisdiction>
				                <CWProcedure>IMPORT</CWProcedure>
							                <DeclarationDestination>CUSTOMSWAREIE</DeclarationDestination>
				                <DocumentRef>71Q0019681</DocumentRef>
				                <SiteID>ORK</SiteID>
				                <AccountCode>G0779837</AccountCode>
			                </DeclarationHeader>
		                </Declaration>
	                </DeclarationList>
                </InputDocument>
            ");

            WebService.WebService webService = new WebService.WebService();

            int statusCode = webService.AnalyzeXmlStructure(xmlDocument);

            if (statusCode != -2)
            {
                throw new Exception("Wrong status code");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace Exercise2
{
    class Program
    {
        public static void Main()
        {
            XDocument xDocument = XDocument.Parse(xmlString);
            string[] refCodes = new[] { "MWB", "TRV", "CAR" };

            List<XElement> elements = xDocument.Descendants("Reference")
                .Where(xe1 => xe1.Attributes("RefCode")
                .Where(ex2 => refCodes.Contains(ex2.Value)).Any())
                .ToList();

            elements = elements.Descendants("RefText").ToList();

            foreach (var element in elements)
            {
                Console.WriteLine("RefCodes:" + element.Parent.Attribute("RefCode").Value);
                Console.WriteLine("RefValues:" + element.Value);
            }
        }

        private static string xmlString = @"
            <InputDocument>
              <DeclarationList>
                <Declaration Command=""DEFAULT"" Version=""5.13"">
                  <DeclarationHeader>
                    <Jurisdiction>IE</Jurisdiction>
                    <CWProcedure>IMPORT</CWProcedure>
                    <DeclarationDestination>CUSTOMSWAREIE</DeclarationDestination>
                    <DocumentRef>71Q0019681</DocumentRef>
                    <SiteID>DUB</SiteID>
                    <AccountCode>G0779837</AccountCode>
                    <Reference RefCode=""MWB"">
                      <RefText>586133622</RefText>
                    </Reference>
                    <Reference RefCode=""KEY"">
                      <RefText>DUB16049</RefText>
                    </Reference>
                    <Reference RefCode=""CAR"">
                      <RefText>71Q0019681</RefText>
                    </Reference>
                    <Reference RefCode=""COM"">
                      <RefText>71Q0019681</RefText>
                    </Reference>
                    <Reference RefCode=""SRC"">
                      <RefText>ECUS</RefText>
                    </Reference>
                    <Reference RefCode=""TRV"">
                      <RefText>1</RefText>
                    </Reference>
                    <Reference RefCode=""CAS"">
                      <RefText>586133622</RefText>
                    </Reference>
                    <Reference RefCode=""HWB"">
                      <RefText>586133622</RefText>
                    </Reference>
                    <Reference RefCode=""UCR"">
                      <RefText>586133622</RefText>
                    </Reference>
                    <Country CodeType=""NUM"" CountryType=""Destination"">IE</Country>
                    <Country CodeType=""NUM"" CountryType=""Dispatch"">CN</Country>
                </DeclarationHeader>
              </Declaration>
            </DeclarationList>
          </InputDocument>
	    ";
    }
}

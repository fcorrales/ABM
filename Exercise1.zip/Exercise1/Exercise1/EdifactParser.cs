﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Exercise1
{
    public class EdifactParser
    {
        public List<string> Segments { get; }

        public List<List<string>> ElementsInSegments { get; private set; }

        private readonly string _delimiter = "+";

        public EdifactParser(List<string> segments) {
            Segments = segments;
            ElementsInSegments = InitializeElementsInSegments();
        }

        private List<List<string>> InitializeElementsInSegments()
        {
            List<List<string>> elementsInSegments = new List<List<string>>();
            try
            {
                Segments.ForEach(segment => elementsInSegments.Add(SplitSegment(segment)));
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to initialize the elements in segments", ex);
            }         
            return elementsInSegments;
        }

        private List<string> SplitSegment(string segment)
        {
            return segment.Split(_delimiter).ToList();
        }

        private string JoinSegment(List<string> elements)
        {
            return string.Join(_delimiter, elements);
        }

        /// <summary>Filter the segments by the speficied element</summary>
        public void FilterSegmentsByElement(string element)
        {
            try
            {
                ElementsInSegments = ElementsInSegments.Where(elements => elements.Contains(element)).ToList();
                Segments.Clear();
                ElementsInSegments.ForEach(elements => Segments.Add(JoinSegment(elements)));
            }
            catch (Exception ex )
            {
                throw new Exception("Unable to filter the segments by element", ex);
            }           
        }

        /// <summary>Gets all elements at the specified indexes.</summary>
        /// <returns>A list of strings of the elements found at the specified index.</returns>
        public List<string> GetElementsAt(List<int> indexes)
        {
            List<string> result = new List<string>();

            if (ElementsInSegments.Any(element => element.Count() <= indexes.Max()))
            {
                throw new IndexOutOfRangeException("The index you are trying to get is out of range");
            }

            try
            {
                ElementsInSegments.ForEach(elements => indexes.ForEach(i => result.Add(elements.ElementAt(i))));
            }
            catch (Exception ex )
            {
                throw new Exception ("Unable to get the elements at the specified indexes", ex) ;
            }
            return result;
        }
    }
}

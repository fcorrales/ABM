﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Exercise1
{
    class Program
    {
        static void Main()
        {
            string path = Directory.GetCurrentDirectory();
            string fileName = "EDIFACT.txt";
            fileName = Path.Combine(path, fileName);

            List<string> segments = File.ReadAllLines(fileName).ToList();

            EdifactParser edifactParser = new EdifactParser(segments);

            edifactParser.FilterSegmentsByElement("LOC");

            List<int> indexes = new List<int>() { 1, 2 };
            
            List<string> elements = edifactParser.GetElementsAt(indexes);

            foreach (var element in elements)
            {
                Console.WriteLine(element);
            }                
        }
    }
}

using System;
using System.Collections.Generic;
using System.Linq;
using Exercise1;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Exercise1Test
{
    [TestClass]
    public class EdifactParserTest
    {
        [TestMethod]
        public void FilterSegmentsByElementWithNoSegments()
        {
            List<string> segments = new List<string>();

            EdifactParser edifactParser = new EdifactParser(segments);
            edifactParser.FilterSegmentsByElement("LOC");

            Assert.AreEqual(edifactParser.Segments.Count, 0);
            Assert.AreEqual(edifactParser.ElementsInSegments.Count, 0);
        }

        [TestMethod]
        public void NoMatchInFilterSegmentsByElement()
        {
            List<string> segments = new List<string>()
            {
                "DTM+9:20090527:102'",
                "BGM+ZEM:::EX+09SEE7JPUV5HC06IC6+Z'"
            };

            EdifactParser edifactParser = new EdifactParser(segments);
            edifactParser.FilterSegmentsByElement("LOC");

            Assert.AreEqual(edifactParser.Segments.Count, 0);
            Assert.AreEqual(edifactParser.ElementsInSegments.Count, 0);
        }

        [TestMethod]
        public void MatchingKeySensitivy()
        {
            List<string> segments = new List<string>()
            {
                "Loc+17+IT044100'",
                "loc+18+SOL'",
                "LOC+35+SE'"
            };

            EdifactParser edifactParser = new EdifactParser(segments);
            edifactParser.FilterSegmentsByElement("LOC");

            Assert.AreEqual(edifactParser.Segments.Count, 1);
        }

        [TestMethod]
        public void GetElementsAtOneElement()
        {
            List<string> segments = new List<string>()
            {
                "LOC+35+SE'",
                "LOC+36+TZ'",
                "LOC+116+SE003033'"
            };

            EdifactParser edifactParser = new EdifactParser(segments);

            List<int> indexes = new List<int>() { 1 };
            List<string> elements = edifactParser.GetElementsAt(indexes);

            List<string> expectedElements = new List<string>() { "35", "36", "116" };

            Assert.IsTrue(elements.SequenceEqual(expectedElements));
        }

        [TestMethod]
        public void GetElementsAtMultipleElements()
        {
            List<string> segments = new List<string>()
            {
                "LOC+35+SE'",
                "LOC+36+TZ'",
                "LOC+116+SE003033'"
            };

            EdifactParser edifactParser = new EdifactParser(segments);

            List<int> indexes = new List<int>() { 1, 2 };
            List<string> elements = edifactParser.GetElementsAt(indexes);

            List<string> expectedElements = new List<string>() { "35", "SE'", "36", "TZ'", "116", "SE003033'" };

            Assert.IsTrue(elements.SequenceEqual(expectedElements));
        }

        [ExpectedException(typeof(IndexOutOfRangeException), "The index you are trying to get is out of range")]
        [TestMethod]
        public void GetElementsAtOutOfRangeIndex()
        {
            List<string> segments = new List<string>()
            {
                "Loc+17+IT044100'",
                "loc+18+SOL'",
                "LOC+35+SE'"
            };

            EdifactParser edifactParser = new EdifactParser(segments);

            List<int> indexes = new List<int>() { 3, 4 };
            edifactParser.GetElementsAt(indexes);
        }
    }
}
